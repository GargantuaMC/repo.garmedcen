if __name__ == "__main__":
    from .main import main
    main()
